insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10001,'Alok Jain','29alok@gmail.com','7701912597','Delhi');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10002,'Amisha Meena','amisha@gmail.com','9874851254','Faridabad');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10003,'Aman Kumar','amanj@gmail.com','7456321485','Jaipur');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10004,'Raman Kohli','raman@gmail.com','1569891232','Hyderabad');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10005,'Mrinal Thakur','tmrinal@gmail.com','7485129685','Bangalore');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10006,'Pradeep Singh','pradip@gmail.com','8596427895','Pune');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10007,Aman Kumar','amanj@gmail.com','7456321485','Jaipur');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(10008,Aman Kumar','amanj@gmail.com','7456321485','Jaipur');
 

 

 


insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1001,'Home Loan',1900000,5.5,24,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1002,'Home Loan',3000000,12.5,28,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1003,'Car Loan',700000,11.5,24,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1004,'Car Loan',600000,12,36,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1005,'Education Loan',500000,12,36,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1006,'Medical Loan',500000,12,25,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1007,'Medical Loan',500000,12,28,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1008,'Home Loan',500000,12,28,'CASH_DEPOSIT');

 

 

 


