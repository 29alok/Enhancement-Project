package com.cts.training.collateralwebportal.feign;

public class LoanNotFoundException extends RuntimeException {

	public LoanNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoanNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public LoanNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LoanNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LoanNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
