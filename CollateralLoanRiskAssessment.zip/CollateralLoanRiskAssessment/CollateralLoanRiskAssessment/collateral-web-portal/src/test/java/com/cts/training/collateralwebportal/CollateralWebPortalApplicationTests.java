package com.cts.training.collateralwebportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollateralWebPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
