insert into user(id, name, password) values (1, 'alok', 'ajain');





insert into customer(id,name,password) values (10011,'pradeep','pradeep');
insert into customer(id,name,password) values (10012,'lavanya','lavan');
